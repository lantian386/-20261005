# reference.md · 版式细则 / 避坑档案 / 自检与验收

> 本档案是 SKILL.md 的细则附件。所有数值均来自已验证交付物（2026-10 两篇人民日报精读双交付实测）。

---

## §0 执行标准（总纲 · 严格执行）

- **确认门**：PDF 构建须在 HTML 交付后经用户确认（是否生成 / 整册 or 仅双栏段）；未确认不构建。
- **构建器唯一**：`assets/build_full_pdf_template.py`（数据驱动 8 注入区）；禁止手写版式绕开模板。
- **参数唯一**：页面 / 边距 / 栏宽 / 组件尺寸 / 色卡 / 字号行距以 §2 为唯一依据；改动须先改本档案再改模板，二者同步升版。
- **自检必过**：§6 三重自检 + §7 验收（含模块对应与数量一致）全绿才交付；任一失败回溯修复后重检。
- **禁止项**：跳过自检、只出双栏段交付、TA_JUSTIFY 滥用、TTC/CFF 字体、/tmp 落文件。

---

## §1 字体供给决策树

目标：`NotoSansSC-400.ttf` + `NotoSansSC-700.ttf`（思源黑体 SC 真 TrueType 静态实例）。

```
1) 缓存命中？  ls .fonts/NotoSansSC-{400,700}.ttf 且均 > 5MB → 直接用
2) 一键供给：  bash assets/fetch_fonts.sh "$WORKDIR/.fonts"
   内部：jsDelivr 多节点回退（cdn → fastly → gcore）下载 NotoSansSC[wght].ttf
        → fontTools.varLib.instancer 实例化 wght=400/700（65k 字约 40-80s/个）
3) 全线失败降级：
   a. /system/fonts/HarmonyOS_Sans_SC.ttf（真 TTF，无独立 700 → bold 复用 regular）
   b. /system/fonts/FZHeiT-SC-{Regular,Bold}.ttf
   c. 都无 → 报错请用户手动放置
4) 严禁：/system/fonts/NotoSansCJK*.ttc、NotoSerifCJK*.ttc
   原因：CFF (PostScript) 轮廓 → reportlab TTFont 抛
   "postscript outlines are not supported"
5) 严禁：raw.githubusercontent.com（连接重置）；思源宋体 notoserifsc 在 jsDelivr 持续 403（超单文件限制），弃衬线、全文黑体
```

注册铁律：

```python
pdfmetrics.registerFont(TTFont("SHS",  ".fonts/NotoSansSC-400.ttf"))
pdfmetrics.registerFont(TTFont("SHSB", ".fonts/NotoSansSC-700.ttf"))
registerFontFamily("SHS", normal="SHS", bold="SHSB", italic="SHS", boldItalic="SHSB")
```

缺 `registerFontFamily` → `<b>` 走 reportlab 描边伪粗（发虚难看）。

---

## §2 PDF 布局参数表（A4 横向）

| 项 | 值 |
|---|---|
| 页面 | landscape(A4) = 842 × 595 pt（297×210mm） |
| 边距 | 左/右 16mm；上 22mm；下 18mm |
| 内容宽 CONTENT_W | 265mm |
| 双栏 | 左 COL_L = 106mm（原文）；gap 6mm；右 COL_R = 153mm（批注） |
| 批注盒内宽 NOTE_IN | COL_R − 2mm − 6mm ≈ 145mm（sent_box / 功能条均用此宽，防溢出） |
| 卡头横条 HBar | 高 24pt；序号方标 19×19pt 圆角 4.5，白 24% 底；标题 13.5pt 真粗 |
| SegTag 段题标签 | 实心主色胶囊，高 16pt，**位于原文框外上方**（不内嵌） |
| 原文框 | 主色左边框 2.5pt + 米黄底 #fbf3e6 + 内边距 9/10pt；原文 10.6pt/18 |
| 批注盒 | 米白底 #fffdf7 + 0.4pt 细边框 #e6dcc4；批注 9.2pt/15 |
| 功能条 | #efe4d0 底、9pt 真粗、内边距 3.5pt |
| chips | 8.2pt、高 15pt、圆角 7、**自动换行**（贪心按可用宽折行） |
| 句式亮点块 | 藏蓝 #2c4a6b 左边框 2.5pt + 淡蓝底 #eef3f9、9pt |
| 金句行（模块④） | 金色 #a5812f 序号胶囊 18mm + 米金底 #fdf6e3；金句 10pt 真粗、出处 8.3pt |
| 脉络图（模块③） | 根节点藏蓝实底居中；L1 #e7eef7 底 31% 宽；L2 #f3f7fc 底 67% 宽 + 虚线左框 |
| 背景卡（模块⑤） | 黛青 #1f6f6b 左边框 2.5pt + #eef7f5 底；双列各 49% 宽 |
| 素材卡（模块⑥） | 茄紫 #6d4c8f 系；原文/仿写对照双栏各半（赭棕头 vs 藏蓝头） |
| 复盘（模块⑦） | 双列：任务清单（墨灰左框）+ 自测题（藏蓝左框） |
| 页眉 | 左品牌红 9pt 真粗；右出处+页码灰 8pt；下沿红 1.2pt + 金 0.4pt 双线 |
| 页脚 | 左版权灰 7.5pt；右「— N —」；上沿金 0.4pt 细线 |
| 封面 | 红渐变横幅 82mm + 上下双白线；旗标/主标 28pt/副题/出处行/4 徽章；下接元信息表 + 金色导语块 |

**排版铁律**：全部 `TA_LEFT`；仅原文块可用 `TA_JUSTIFY`（无 `<br/>` 时安全）。任何含 `<br/>` 的段落一律左对齐。

---

## §3 HTML 版式规范（纸墨红金 · 报章风）

- 容器 `max-width:920px` 居中；页面背景 `linear-gradient(160deg,#f7f1e5,#efe3cf)`。
- 报头 Hero：红渐变 `#c7000b→#8f1414`，上沿 3px 白线 + 下沿 6px 双白线；白字标题 + 4 半透明胶囊徽章（来源版面/体裁/契合度/建议用时）。
- 模块卡：米白底 #fffdf7、圆角 18px、暖投影；卡头 = 模块专属色实色横条 + 序号方标 + 标题。
  色卡：① 赭棕 #8a4b12 ② 人民红 #c7000b ③ 藏蓝 #2c4a6b ④ 金黄 #a5812f ⑤ 黛青 #1f6f6b ⑥ 茄紫 #6d4c8f ⑦ 墨灰 #4b5563。
- 微元件：`.orig` 宋体/红左边框/米黄底/右上段号；`.w` 红字加粗内联；`.s` 藏蓝左框句式块；`.q` 金底金左框 ★ 金句 + 出处行；`.chip` 红系胶囊；脉络图藏蓝嵌套块；`.bgx` 黛青左框背景块；`.mat` 茄紫系素材卡；`.k3` 三栏金句卡；`.dui` 原文/仿写左右对照；`.act` ★ 要点列表。
- 响应式：≤640px 时 `.dui` 单列、Hero 标题 22px；正文行高 ≥1.8、字号 ≥15px。
- 页脚：生成方声明 + 原文出处链接 + 「可离线打开 / 打印」。

---

## §4 build_full_pdf_template.py 内容注入区（8 区）

模板顶部「用户配置区」按序填：

1. `META` — title / subtitle / source / author / brand / copyright / output
2. `SEGMENTS` — 模块②双栏段列表：`segno / orig(可含 <font color> 强调) / func / chips[] / notes[](字符串列表) / sent(可 None)`
3. `M1_*` — 模块①：`M1_BLOCKS[(标题, 正文html)]`、`M1_CHIPS[]`、`M1_FIT[(_lead, body)×4]`、`M1_STRATEGY[html×3]`
4. `M3_*` — 模块③：`M3_ROOT`、`M3_ROWS[(L1标题, [L2…])]`、`M3_TIP`
5. `M4_*` — 模块④：`M4_GROUPS[(组名, [(段号, 金句, 适用)…])]`、`M4_NOTE`
6. `M5_*` — 模块⑤：`M5_ITEMS[(tag, 标题, 正文)×6]`、`M5_REFS[]`、`M5_NOTE`
7. `M6_*` — 模块⑥：`M6_TITLES / M6_SENTS[(tag, 名, 模板, 原句, 仿写)]`、`M6_FEN{total, subs×3, demo}`、`M6_CARDS×5`、`M6_EXS×2`、`M6_LOSS×4`
8. `M7_*` — 模块⑦：`M7_ACT[(lead, body)×5]`、`M7_QUIZ[×5]`

填完后 `python3 build_full_pdf_template.py` 直接出整册。模板自带最小示例数据，可先空跑验证环境。

---

## §5 避坑清单 Top 10

1. **TTC/CFF 拒嵌** → 见 §1；报错原文 "postscript outlines are not supported"。
2. **TA_JUSTIFY + `<br/>`/`<b>` 拉伸** → 短行字间距被撑到 20pt+；除无 `<br/>` 的原文块外全用 TA_LEFT。
3. **chips 单行硬塞溢出右栏** → 用贪心换行 Chip（wrap 内按可用宽折行）或 Table 分行。
4. **嵌套盒宽度超限** → 批注盒内宽 = COL_R−2mm−盒内边距；sent_box/功能条统一用 NOTE_IN。
5. **/tmp 只读（OHOS）** → 一切临时文件落工作目录；用完 mv 进 `.trash/`。
6. **WebFetch 超时** → paper.people.com.cn 用 curl + UA；正文在 `div#articleContent`。
7. **KeepTogether 大段留白** → 双栏段整块 KeepTogether 可接受（每页 2 段）；若单段过高拆 notes。
8. **伪粗体** → 必须 registerFontFamily，否则 `<b>` 描边发虚。
9. **稀疏页** → 模块③/④行高预估：末分支+结论块总高不足一页时提前换页或压缩行距；pypdf 抽取后每页去空白 <500 字视为稀疏需回溯。
10. **模块缺失** → PDF 只出双栏段 = 不合格；验收必查 7 模块标题齐全（见 §7）。

---

## §6 三重自检脚本

```bash
# A 页数 + 尺寸
python3 -c "
from pypdf import PdfReader
r = PdfReader('OUTPUT.pdf')
print('页数:', len(r.pages), '| 尺寸:', float(r.pages[0].mediabox.width), 'x', float(r.pages[0].mediabox.height))
assert len(r.pages) >= 3 and abs(float(r.pages[0].mediabox.width) - 842) < 2
"
# B 越界告警
grep -iE "warning|overflow|too large|frame" build.log && echo 有告警 || echo 无越界告警
# C 文本还原抽查（首 / 中 / 尾）
python3 -c "
from pypdf import PdfReader; import re
r = PdfReader('OUTPUT.pdf'); n = len(r.pages)
for i in [0, n//2, n-1]:
    t = re.sub(r'\s+', ' ', r.pages[i].extract_text())
    print(f'--- P{i+1} ({len(t)}字) ---'); print(t[:240])
"
```

## §7 验收清单（含「模块对应」专项）

- [ ] 页数 ≥ 3；首页 842×595pt；build.log 无告警；抽查无 tofu（□）无缺字
- [ ] `<b>` 为真粗体（视觉明显重于正文）
- [ ] 双栏无跨栏溢出（chips / 长 URL / 长英文词）
- [ ] **模块对应**：PDF 文本可检索到「选文定位 / 逐段精读 / 逻辑脉络 / 金句速览 / 时政背景 / 申论素材 / 复盘行动」7 个模块标题
- [ ] **数量一致**：金句条数、句式模板数、金句卡数、仿写练习数、自测题数 PDF ≡ HTML
- [ ] 两版页脚均含版权声明与原文链接
- [ ] 无稀疏页（每页去空白 ≥500 字）
