#!/usr/bin/env bash
# ============================================================================
# fetch_fonts.sh · 思源黑体 SC TTF 一键供给脚本
# ----------------------------------------------------------------------------
# 目标：在 $DEST 下产出 NotoSansSC-400.ttf 与 NotoSansSC-700.ttf
# 路线：jsDelivr 多节点回退下载可变字体 → fontTools instancer 实例化两个静态字重
#
# 用法：
#   bash fetch_fonts.sh [DEST_DIR]
#   DEST_DIR 默认为 ./.fonts
#
# 依赖：curl、python3、fontTools
# ============================================================================
set -u

DEST="${1:-./.fonts}"
mkdir -p "$DEST"
cd "$DEST" || { echo "[ERR] cannot cd $DEST"; exit 1; }

REGULAR="NotoSansSC-400.ttf"
BOLD="NotoSansSC-700.ttf"
VAR="NotoSansSC-var.ttf"
MIN_SIZE=$((5*1024*1024))   # 5 MB 最小阈值，低于视为下载失败

# ---------------------------------------------------------------------------
# Step 0: 缓存命中检测
# ---------------------------------------------------------------------------
if [[ -f "$REGULAR" && -f "$BOLD" ]]; then
  r_sz=$(stat -c%s "$REGULAR" 2>/dev/null || stat -f%z "$REGULAR" 2>/dev/null || echo 0)
  b_sz=$(stat -c%s "$BOLD"     2>/dev/null || stat -f%z "$BOLD"     2>/dev/null || echo 0)
  if (( r_sz > MIN_SIZE && b_sz > MIN_SIZE )); then
    echo "[HIT] cache valid: $REGULAR ($r_sz bytes) + $BOLD ($b_sz bytes)"
    echo "      skip download & instancing."
    exit 0
  fi
  echo "[WARN] cache exists but too small, will re-fetch"
fi

# ---------------------------------------------------------------------------
# Step 1: 依赖检查
# ---------------------------------------------------------------------------
command -v curl    >/dev/null || { echo "[ERR] curl not found";    exit 2; }
command -v python3 >/dev/null || { echo "[ERR] python3 not found"; exit 2; }
python3 -c "import fontTools" 2>/dev/null || {
  echo "[ERR] fontTools not installed. Run: pip install fonttools"
  exit 2
}

# ---------------------------------------------------------------------------
# Step 2: 下载可变字体（jsDelivr 多节点回退）
# 备注：
#   - 严禁 raw.githubusercontent.com（在部分网络下会被重置）
#   - 严禁 /system/fonts/NotoSansCJK*.ttc（CFF 轮廓，reportlab 拒嵌）
#   - notoserifsc 的 [wght].ttf 在 jsDelivr 上会 403（超限），故只走 sans
# ---------------------------------------------------------------------------
URL_PATH="gh/google/fonts@main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf"
HOSTS=("cdn.jsdelivr.net" "fastly.jsdelivr.net" "gcore.jsdelivr.net")

if [[ ! -f "$VAR" ]] || (( $(stat -c%s "$VAR" 2>/dev/null || echo 0) < MIN_SIZE )); then
  rm -f "$VAR"
  ok=0
  for h in "${HOSTS[@]}"; do
    echo "[GET] https://$h/$URL_PATH"
    curl -sSL --max-time 180 -o "$VAR" "https://$h/$URL_PATH" \
      -w "      HTTP:%{http_code} SIZE:%{size_download}\n" || true
    sz=$(stat -c%s "$VAR" 2>/dev/null || stat -f%z "$VAR" 2>/dev/null || echo 0)
    if (( sz > MIN_SIZE )); then
      echo "[OK ] variable font downloaded via $h ($sz bytes)"
      ok=1; break
    fi
    echo "[WARN] $h failed (size=$sz), trying next mirror..."
    rm -f "$VAR"
  done
  if (( ok == 0 )); then
    echo "[ERR] all jsDelivr mirrors failed."
    echo "      fallback: manually place NotoSansSC-400.ttf & NotoSansSC-700.ttf in $DEST"
    echo "      or use system TTF (see reference.md §5)."
    exit 3
  fi
fi

# ---------------------------------------------------------------------------
# Step 3: fontTools instancer 实例化 400 / 700 静态字重
# 备注：instancer 一次实例化 65k+ 字形约 40-80 秒，两个共 1-3 分钟
# ---------------------------------------------------------------------------
python3 - <<'PY'
import sys, time, os
try:
    from fontTools.ttLib import TTFont
    from fontTools.varLib import instancer
except ImportError as e:
    print(f"[ERR] fontTools import failed: {e}"); sys.exit(4)

VAR = "NotoSansSC-var.ttf"
targets = [(400, "NotoSansSC-400.ttf"), (700, "NotoSansSC-700.ttf")]

for wght, out in targets:
    if os.path.exists(out) and os.path.getsize(out) > 5*1024*1024:
        print(f"[SKIP] {out} already exists ({os.path.getsize(out)} bytes)")
        continue
    t0 = time.time()
    print(f"[INST] wght={wght} -> {out} ...", flush=True)
    try:
        f = TTFont(VAR)
        instancer.instantiateVariableFont(
            f, {"wght": wght}, inplace=True, updateFontNames=False
        )
        f.save(out)
        sz = os.path.getsize(out)
        print(f"[OK ] {out} ({sz} bytes, {time.time()-t0:.1f}s)")
    except Exception as e:
        print(f"[ERR] instance wght={wght} failed: {e}")
        sys.exit(5)
PY
rc=$?
if (( rc != 0 )); then
  echo "[ERR] fontTools instancer failed (rc=$rc)"
  exit $rc
fi

# ---------------------------------------------------------------------------
# Step 4: 最终校验
# ---------------------------------------------------------------------------
echo "----- result -----"
for f in "$REGULAR" "$BOLD"; do
  if [[ -f "$f" ]]; then
    sz=$(stat -c%s "$f" 2>/dev/null || stat -f%z "$f" 2>/dev/null || echo 0)
    if (( sz > MIN_SIZE )); then
      echo "[OK ] $f  $sz bytes"
    else
      echo "[ERR] $f too small ($sz bytes)"
      exit 6
    fi
  else
    echo "[ERR] $f missing"
    exit 6
  fi
done

echo ""
echo "Fonts ready at: $(pwd)/$REGULAR , $(pwd)/$BOLD"
echo "Next: point build_twocol_pdf.py FONT_DIR to this directory and run it."
exit 0
