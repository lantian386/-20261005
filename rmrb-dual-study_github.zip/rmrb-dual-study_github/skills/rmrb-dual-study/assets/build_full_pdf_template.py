#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_full_pdf_template.py · 人民日报精读 · 七模块整册 PDF 构建模板（A4 横向 · 左原文右批注 · 思源黑体）
==========================================================================================
用法：
  1. bash fetch_fonts.sh ./.fonts          # 备好思源黑体 SC 400/700（缓存命中自动跳过）
  2. 复制本模板到工作目录，按「内容注入区」8 区填数据（META / SEGMENTS / M1 / M3 / M4 / M5 / M6 / M7）
  3. python3 build_full_pdf_template.py
  4. 跑 reference.md §6 三重自检 + §7 模块对应验收

排版铁律（勿改）：
  - 全篇 TA_LEFT（仅原文块 TA_JUSTIFY 且不得含 <br/>）
  - chips 贪心换行防溢出；批注盒内组件统一用 NOTE_IN 宽
  - SegTag 段题红标签位于原文框外上方
  - registerFontFamily 让 <b> 走真粗体
  - 模块②双栏：左 COL_L=106mm 原文 / 右 COL_R=153mm 批注
"""

import os
import sys

from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, Flowable, NextPageTemplate
)

# ============================================================================
# 【内容注入区 0 · 字体与主题】
# ============================================================================
FONT_DIR = os.environ.get("TWOCOL_FONT_DIR", "./.fonts")
FONT_REG = os.path.join(FONT_DIR, "NotoSansSC-400.ttf")
FONT_BLD = os.path.join(FONT_DIR, "NotoSansSC-700.ttf")

RED     = colors.HexColor("#c7000b"); RED2   = colors.HexColor("#8f1414")
OCHRE   = colors.HexColor("#8a4b12"); NAVY   = colors.HexColor("#2c4a6b")
GOLD    = colors.HexColor("#a5812f"); TEAL   = colors.HexColor("#1f6f6b")
PLUM    = colors.HexColor("#6d4c8f"); GRAY   = colors.HexColor("#4b5563")
INK     = colors.HexColor("#2b2417"); SUB    = colors.HexColor("#6b5d45")
PAPER   = colors.HexColor("#f7f1e5"); PAPER2 = colors.HexColor("#efe3cf")
CARD    = colors.HexColor("#fffdf7")
ORIG_BG = colors.HexColor("#fbf3e6"); QUOTE_BG = colors.HexColor("#fdf6e3")
BLUE_BG = colors.HexColor("#eef3f9"); TEAL_BG  = colors.HexColor("#eef7f5")
PLUM_BG = colors.HexColor("#f8f4fc")
LINE    = colors.HexColor("#d9c9a8")
CHIP_BG = colors.HexColor("#fbe9e9"); CHIP_BD = colors.HexColor("#f0c4c4")

# ============================================================================
# 【内容注入区 1 · META】
# ============================================================================
META = {
    "title":     "示例文章标题",
    "subtitle":  "——示例副题：一句话点出全文切口与落点",
    "flag":      "人 民 日 報 精 讀 · 栏 目 名",
    "source":    "人民日报 · YYYY-MM-DD · 第05版 评论",
    "author":    "作者名",
    "brand":     "人民日报精读",
    "badges":    ["体裁：评论员观察", "契合度：★★★★★", "建议用时：12-15 分钟", "作者：作者名"],
    "source_line": "原文出处：人民日报电子报 paper.people.com.cn · YYYY 年 M 月 D 日 · 第 05 版（评论）",
    "copyright": "个人学习精读 · 原文版权归《人民日报》及作者所有",
    "output":    "示例-精读.pdf",
}

# ============================================================================
# 【内容注入区 2 · SEGMENTS（模块②双栏段）】
# 字段：segno 段题 / orig 原文(可含 <font color='#c7000b'><b>…</b></font> 红强调、★ 金句前缀)
#       func 功能标签 / chips 手法胶囊 / notes 赏析字符串列表 / sent 句式亮点(可 None)
# ============================================================================
SEGMENTS = [
    {
        "segno": "段 1 · 示例段题",
        "orig":  "这里是<b>原文</b>示例。重点词用红粗内联标注，值得背诵的句子前缀 ★。",
        "func":  "功能定位 · 示例",
        "chips": ["手法一", "手法二", "手法三"],
        "notes": ["第一条赏析：先点手法，再析效果。", "第二条赏析：关联全文主旨。"],
        "sent":  "句式亮点：★「模板句」——一句话说明可迁移场景。",
    },
]

# ============================================================================
# 【内容注入区 3 · M1（模块①选文定位）】
# ============================================================================
M1_BLOCKS   = [("▎ 体裁定位", "示例：「新闻由头 + 分层点评」结构说明……")]
M1_CHIPS    = ["话题一", "话题二", "话题三"]
M1_FIT      = [("<b>① 话题常见度高</b>", "理由……"), ("<b>② 结构典型性强</b>", "理由……"),
               ("<b>③ 表达可迁移性高</b>", "理由……"), ("<b>④ 思想落点稳</b>", "理由……")]
M1_STRATEGY = ["<b>1. 策略一</b> — ……", "<b>2. 策略二</b> — ……", "<b>3. 策略三</b> — ……"]

# ============================================================================
# 【内容注入区 4 · M3（模块③逻辑脉络）】
# ============================================================================
M3_ROOT = "全文主题句"
M3_ROWS = [
    ("起 · 示例层（段 x—x）", ["节点一", "节点二"]),
    ("合 · 收束升华（段 x）", ["节点一", "节点二"]),
]
M3_TIP = "<b>骨架一句话：</b>「……」。点出可迁移机关。"

# ============================================================================
# 【内容注入区 5 · M4（模块④金句速览）]
# ============================================================================
M4_GROUPS = [
    ("A. 示例组", [("段 x", "金句原文。", "适用场景说明。")]),
]
M4_NOTE = "※ 全文可背金句共 <b>N</b> 条，按功能分组背诵。"

# ============================================================================
# 【内容注入区 6 · M5（模块⑤时政背景）】
# ============================================================================
M5_ITEMS = [
    ("tag", "标题", "正文：政策注明出处+年份；查不到写「待核实」。"),
    ("tag", "标题", "正文……"),
]
M5_REFS = ["《人民日报》YYYY 年 M 月 D 日第 05 版原文：《标题（栏目）》，作者。", "权威文件（年份）。"]
M5_NOTE = "※ 政策原文表述与数据口径以权威发布为准。"

# ============================================================================
# 【内容注入区 7 · M6（模块⑥申论素材）】
# ============================================================================
M6_TITLES = [("题式 1", "题式名", "说明……", "原文标题", "仿写一 / 仿写二")]
M6_SENTS  = [("句式 1", "句式名（段 x）", "[模板……]", "原句……", "仿写……")]
M6_FEN    = {
    "total": "总论点……",
    "subs":  [("分论点 1（名）", "内容……"), ("分论点 2（名）", "内容……"), ("分论点 3（名）", "内容……")],
    "demo":  "示范段落正文……",
}
M6_CARDS  = [("卡 1 · 主题", "观点……", "原句……", "替换场景……", "段 x")]
M6_EXS    = [("练习 1", "题目……", "<b>示范</b>：参考写法……", "① ……&nbsp; ② ……")]
M6_LOSS   = ["<b>① 失分点一</b> — ……", "<b>② 失分点二</b> — ……"]

# ============================================================================
# 【内容注入区 8 · M7（模块⑦复盘行动）】
# ============================================================================
M7_ACT  = [("<b>今日背诵</b>", "……"), ("<b>本周仿写</b>", "……"), ("<b>本月迁移</b>", "……"),
           ("<b>素材积累</b>", "……"), ("<b>延伸阅读</b>", "……")]
M7_QUIZ = ["自测题 1……", "自测题 2……", "自测题 3……", "自测题 4……", "自测题 5……"]

# ============================================================================
# 【框架区 · 以下勿改（除非调整版式参数）】
# ============================================================================
PAGE = landscape(A4); PW, PH = PAGE
MARGIN_L = MARGIN_R = 16*mm; MARGIN_T = 22*mm; MARGIN_B = 18*mm
CONTENT_W = PW - MARGIN_L - MARGIN_R
COL_GAP = 6*mm; COL_L = 106*mm; COL_R = CONTENT_W - COL_L - COL_GAP
NOTE_IN = COL_R - 2*mm - 6*mm

for p, label in [(FONT_REG, "400"), (FONT_BLD, "700")]:
    if not os.path.exists(p) or os.path.getsize(p) < 5*1024*1024:
        print(f"[ERR] font missing/too small: {p} → run: bash fetch_fonts.sh {FONT_DIR}")
        sys.exit(2)
pdfmetrics.registerFont(TTFont("SHS", FONT_REG))
pdfmetrics.registerFont(TTFont("SHSB", FONT_BLD))
registerFontFamily("SHS", normal="SHS", bold="SHSB", italic="SHS", boldItalic="SHSB")
FONT_NOTE, FONT_ORIG, FONT_B = "SHS", "SHS", "SHSB"

def st(name, **kw):
    base = dict(fontName=FONT_NOTE, fontSize=9.2, leading=14.6, textColor=INK,
                alignment=TA_LEFT, spaceBefore=0, spaceAfter=0)
    base.update(kw); return ParagraphStyle(name, **base)

S = {
  "orig":      st("orig", fontName=FONT_ORIG, fontSize=10.6, leading=18, alignment=TA_JUSTIFY),
  "note_func": st("note_func", fontName=FONT_B, fontSize=9, leading=13, textColor=SUB),
  "note_body": st("note_body", fontSize=9.2, leading=15),
  "note_sent": st("note_sent", fontSize=9, leading=14, textColor=colors.HexColor("#243b57")),
  "h4": st("h4", fontName=FONT_B, fontSize=10.5, leading=15, textColor=colors.HexColor("#6b3a10")),
  "body":    st("body", fontSize=9.5, leading=16),
  "body_sm": st("body_sm", fontSize=8.8, leading=14),
  "sub":     st("sub", fontSize=8.5, leading=12.5, textColor=SUB),
  "quote":     st("quote", fontName=FONT_B, fontSize=10, leading=16, textColor=colors.HexColor("#5f4a13")),
  "quote_src": st("quote_src", fontSize=8.3, leading=12, textColor=colors.HexColor("#8a6d1f")),
  "mm_root": st("mm_root", fontName=FONT_B, fontSize=13, leading=18, textColor=colors.white, alignment=TA_CENTER),
  "mm_l1":   st("mm_l1", fontName=FONT_B, fontSize=10.5, leading=15, textColor=colors.HexColor("#1e3a5f")),
  "mm_l2":   st("mm_l2", fontSize=9, leading=13.5, textColor=colors.HexColor("#274b6d")),
  "mat_h":   st("mat_h", fontName=FONT_B, fontSize=10.5, leading=15, textColor=colors.HexColor("#4c2f6b")),
  "mat_b":   st("mat_b", fontSize=9.2, leading=15),
  "mat_src": st("mat_src", fontName=FONT_ORIG, fontSize=9.4, leading=15, textColor=colors.HexColor("#5a3a10")),
  "mat_to":  st("mat_to", fontSize=9.2, leading=15, textColor=colors.HexColor("#243b57")),
  "white8":  st("white8", fontName=FONT_B, fontSize=8, leading=11, textColor=colors.white, alignment=TA_CENTER),
}
def P(t, s): return Paragraph(t, S[s])

class HBar(Flowable):
    def __init__(s, w, h, color, num, title):
        Flowable.__init__(s); s.w, s.h, s.c, s.num, s.title = w, h, color, num, title
    def wrap(s, aw, ah): return (s.w, s.h)
    def draw(s):
        c = s.canv
        c.setFillColor(s.c); c.roundRect(0, 0, s.w, s.h, 5, stroke=0, fill=1)
        sq = 19; y = (s.h - sq)/2.0
        c.setFillColor(colors.white); c.setFillAlpha(0.24)
        c.roundRect(11, y, sq, sq, 4.5, stroke=0, fill=1); c.setFillAlpha(1)
        c.setFont(FONT_B, 11.5); c.setFillColor(colors.white)
        c.drawCentredString(11 + sq/2.0, y + sq/2.0 - 4, str(s.num))
        c.setFont(FONT_B, 13.5)
        c.drawString(11 + sq + 10, s.h/2.0 - 5, s.title)

class Chip(Flowable):
    """胶囊组 · 贪心自动换行（防溢出右栏）"""
    def __init__(s, items, bg, fg, bd, font=FONT_B, fs=8.2, pad=6.5, h=15, gap=5, vgap=4):
        Flowable.__init__(s)
        s.items, s.bg, s.fg, s.bd = items, bg, fg, bd
        s.font, s.fs, s.pad, s.h, s.gap, s.vgap = font, fs, pad, h, gap, vgap
        s._lines = []
    def wrap(s, aw, ah):
        lines, cur, curw = [], [], 0
        for it in s.items:
            w = pdfmetrics.stringWidth(it, s.font, s.fs) + s.pad*2
            if cur and curw + w + s.gap > aw:
                lines.append(cur); cur, curw = [(it, w)], w
            else:
                cur.append((it, w)); curw += (w + s.gap if len(cur) > 1 else w)
        if cur: lines.append(cur)
        s._lines = lines
        widths = [sum(w for _, w in ln) + s.gap*(len(ln)-1) for ln in lines] or [0]
        return (min(max(widths), aw), len(lines)*s.h + (len(lines)-1)*s.vgap)
    def draw(s):
        c = s.canv
        total_h = len(s._lines)*s.h + (len(s._lines)-1)*s.vgap
        y = total_h - s.h
        for ln in s._lines:
            x = 0
            for it, w in ln:
                c.setFillColor(s.bg); c.setStrokeColor(s.bd); c.setLineWidth(0.5)
                c.roundRect(x, y, w, s.h-1.5, 7, stroke=1, fill=1)
                c.setFillColor(s.fg); c.setFont(s.font, s.fs)
                c.drawString(x + s.pad, y + (s.h-1.5)/2.0 - s.fs*0.36, it)
                x += w + s.gap
            y -= s.h + s.vgap

class SegTag(Flowable):
    """段题红标签 · 位于原文框外上方"""
    def __init__(s, text, bg=RED, fg=colors.white, font=FONT_B, fs=8.6, pad=7, h=16):
        Flowable.__init__(s); s.text, s.bg, s.fg, s.font, s.fs, s.pad, s.h = text, bg, fg, font, fs, pad, h
    def wrap(s, aw, ah):
        s._w = pdfmetrics.stringWidth(s.text, s.font, s.fs) + s.pad*2
        return (s._w, s.h)
    def draw(s):
        c = s.canv
        c.setFillColor(s.bg); c.roundRect(0, 0, s._w, s.h, 4, stroke=0, fill=1)
        c.setFillColor(s.fg); c.setFont(s.font, s.fs)
        c.drawString(s.pad, s.h/2.0 - s.fs*0.36, s.text)

class StarRule(Flowable):
    def __init__(s, w): Flowable.__init__(s); s.w = w
    def wrap(s, aw, ah): return (s.w, 9)
    def draw(s):
        c = s.canv
        c.setStrokeColor(GOLD); c.setLineWidth(0.6)
        c.line(0, 4.5, s.w/2-9, 4.5); c.line(s.w/2+9, 4.5, s.w, 4.5)
        c.setFillColor(GOLD); c.setFont(FONT_B, 9); c.drawCentredString(s.w/2, 2, "★")

class CoverBanner(Flowable):
    def __init__(s, w, h): Flowable.__init__(s); s.w, s.h = w, h
    def wrap(s, aw, ah): return (s.w, s.h)
    def draw(s):
        c = s.canv; w, h = s.w, s.h
        c.setFillColor(RED); c.rect(0, 0, w, h, stroke=0, fill=1)
        c.setFillColor(RED2); c.setFillAlpha(0.6); c.rect(w*0.5, 0, w*0.5, h, stroke=0, fill=1); c.setFillAlpha(1)
        c.setStrokeColor(colors.white)
        c.setLineWidth(1.8); c.line(9, h-4, w-9, h-4)
        c.setLineWidth(0.6); c.line(9, h-8.5, w-9, h-8.5)
        c.setLineWidth(0.6); c.line(9, 11, w-9, 11)
        c.setLineWidth(1.8); c.line(9, 5.5, w-9, 5.5)
        c.setFillColor(colors.HexColor("#ffd9a0")); c.setFont(FONT_B, 10)
        c.drawString(24, h-27, META.get("flag", ""))
        c.setFillColor(colors.white); c.setFont(FONT_B, 28)
        c.drawString(24, h-60, META.get("title", ""))
        c.setFillColor(colors.HexColor("#ffe6c7")); c.setFont(FONT_NOTE, 11)
        c.drawString(24, h-78, META.get("subtitle", ""))
        c.setFillColor(colors.white); c.setFillAlpha(0.85); c.setFont(FONT_NOTE, 8.5)
        c.drawString(24, 40, META.get("source_line", ""))
        c.setFillAlpha(1)
        x = 24; c.setFont(FONT_B, 8.5)
        for b in META.get("badges", []):
            bw = pdfmetrics.stringWidth(b, FONT_B, 8.5) + 18
            c.setFillColor(colors.white); c.setFillAlpha(0.22)
            c.roundRect(x, 18, bw, 16, 8, stroke=0, fill=1); c.setFillAlpha(1)
            c.setFillColor(colors.white); c.drawString(x+9, 23, b)
            x += bw + 7

def on_page(canv, doc):
    canv.saveState()
    canv.setFillColor(RED); canv.setFont(FONT_B, 9)
    canv.drawString(MARGIN_L, PH-14*mm, META.get("brand", ""))
    canv.setFillColor(SUB); canv.setFont(FONT_NOTE, 8)
    canv.drawRightString(PW-MARGIN_R, PH-14*mm, f"{META.get('source', '')} · {META.get('author', '')} · P{canv.getPageNumber():02d}")
    canv.setStrokeColor(RED); canv.setLineWidth(1.2); canv.line(MARGIN_L, PH-16*mm, PW-MARGIN_R, PH-16*mm)
    canv.setStrokeColor(GOLD); canv.setLineWidth(0.4); canv.line(MARGIN_L, PH-17*mm, PW-MARGIN_R, PH-17*mm)
    canv.setStrokeColor(LINE); canv.setLineWidth(0.4); canv.line(MARGIN_L, 12*mm, PW-MARGIN_R, 12*mm)
    canv.setFillColor(SUB); canv.setFont(FONT_NOTE, 7.5)
    canv.drawString(MARGIN_L, 8*mm, META.get("copyright", ""))
    canv.drawRightString(PW-MARGIN_R, 8*mm, f"— {canv.getPageNumber()} —")
    canv.restoreState()

def on_cover(canv, doc):
    canv.saveState()
    canv.setFillColor(PAPER); canv.rect(0, 0, PW, PH, stroke=0, fill=1)
    canv.setFillColor(PAPER2); canv.setFillAlpha(0.4); canv.rect(0, 0, PW, PH*0.42, stroke=0, fill=1)
    canv.setFillAlpha(1); canv.restoreState()

def card_head(num, title, color): return HBar(CONTENT_W, 24, color, num, title)

def orig_box(paras, width=COL_L, bg=ORIG_BG, bar=RED):
    t = Table([[paras]], colWidths=[width-4*mm])
    t.setStyle(TableStyle([
        ("LEFTPADDING",(0,0),(-1,-1), 9), ("RIGHTPADDING",(0,0),(-1,-1), 10),
        ("TOPPADDING",(0,0),(-1,-1), 9), ("BOTTOMPADDING",(0,0),(-1,-1), 9),
        ("BACKGROUND",(0,0),(-1,-1), bg),
        ("LINEBEFORE",(0,0),(0,-1), 2.5, bar),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    return t

def note_box(paras, width=COL_R, bg=CARD):
    t = Table([[paras]], colWidths=[width-2*mm])
    t.setStyle(TableStyle([
        ("LEFTPADDING",(0,0),(-1,-1), 9), ("RIGHTPADDING",(0,0),(-1,-1), 9),
        ("TOPPADDING",(0,0),(-1,-1), 7), ("BOTTOMPADDING",(0,0),(-1,-1), 7),
        ("BACKGROUND",(0,0),(-1,-1), bg),
        ("BOX",(0,0),(-1,-1), 0.4, colors.HexColor("#e6dcc4")),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    return t

def func_chip(func_txt, chips):
    inner = []
    ft = Table([[P(f"<b>功能</b> · {func_txt}", "note_func")]], colWidths=[NOTE_IN])
    ft.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#efe4d0")),
        ("LEFTPADDING",(0,0),(-1,-1), 9), ("RIGHTPADDING",(0,0),(-1,-1), 9),
        ("TOPPADDING",(0,0),(-1,-1), 3.5), ("BOTTOMPADDING",(0,0),(-1,-1), 3.5),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
    ]))
    inner.append(ft); inner.append(Spacer(1, 4))
    if chips:
        inner.append(Chip(chips, CHIP_BG, RED2, CHIP_BD)); inner.append(Spacer(1, 5))
    return inner

def sent_box(txt, width=None):
    w = width or NOTE_IN
    t = Table([[P(txt, "note_sent")]], colWidths=[w])
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), BLUE_BG),
        ("LINEBEFORE",(0,0),(0,-1), 2.5, NAVY),
        ("LEFTPADDING",(0,0),(-1,-1), 10), ("RIGHTPADDING",(0,0),(-1,-1), 10),
        ("TOPPADDING",(0,0),(-1,-1), 6), ("BOTTOMPADDING",(0,0),(-1,-1), 6),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    return t

def block(title, flows, color, bg=CARD, width=None):
    w = width or CONTENT_W
    inner = [P(title, "h4"), Spacer(1, 3)] + flows
    t = Table([[inner]], colWidths=[w-4*mm])
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), bg),
        ("LINEBEFORE",(0,0),(0,-1), 3, color),
        ("BOX",(0,0),(-1,-1), 0.4, LINE),
        ("LEFTPADDING",(0,0),(-1,-1), 13), ("RIGHTPADDING",(0,0),(-1,-1), 13),
        ("TOPPADDING",(0,0),(-1,-1), 10), ("BOTTOMPADDING",(0,0),(-1,-1), 10),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    return t

def dui_row(orig, imit, w):
    hr = Table([[P("<b>原文</b>", "white8"), P("<b>仿写</b>", "white8")]], colWidths=[w/2, w/2])
    hr.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(0,0), OCHRE), ("BACKGROUND",(1,0),(1,0), NAVY),
        ("LEFTPADDING",(0,0),(-1,-1), 10), ("RIGHTPADDING",(0,0),(-1,-1), 10),
        ("TOPPADDING",(0,0),(-1,-1), 3), ("BOTTOMPADDING",(0,0),(-1,-1), 3),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
    ]))
    br = Table([[P(orig, "mat_src"), P(imit, "mat_to")]], colWidths=[w/2, w/2])
    br.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(0,0), colors.HexColor("#fbf3e6")),
        ("BACKGROUND",(1,0),(1,0), colors.HexColor("#f3f7fc")),
        ("LEFTPADDING",(0,0),(-1,-1), 10), ("RIGHTPADDING",(0,0),(-1,-1), 10),
        ("TOPPADDING",(0,0),(-1,-1), 7), ("BOTTOMPADDING",(0,0),(-1,-1), 7),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("LINEBEFORE",(0,0),(0,-1), 0.4, LINE), ("LINEAFTER",(0,0),(0,-1), 0.4, LINE),
        ("LINEBELOW",(0,0),(-1,-1), 0.4, LINE),
    ]))
    return [hr, br]

MAT_IN = CONTENT_W - 4*mm - 9*mm
def mat_wrap(inner):
    t = Table([[inner]], colWidths=[CONTENT_W-4*mm])
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), PLUM_BG), ("BOX",(0,0),(-1,-1), 0.5, colors.HexColor("#d9c9ea")),
        ("LEFTPADDING",(0,0),(-1,-1), 14), ("RIGHTPADDING",(0,0),(-1,-1), 14),
        ("TOPPADDING",(0,0),(-1,-1), 10), ("BOTTOMPADDING",(0,0),(-1,-1), 10),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    return t

def mat_section_header(txt):
    h = Table([[P(txt, "mat_h")]], colWidths=[CONTENT_W])
    h.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#efe4f5")), ("LINEBEFORE",(0,0),(0,-1), 3, PLUM),
        ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
        ("TOPPADDING",(0,0),(-1,-1), 5), ("BOTTOMPADDING",(0,0),(-1,-1), 5),
    ]))
    return h

# ----------------------------------------------------------------------------
# 模块构建器（读全局注入区数据）
# ----------------------------------------------------------------------------
def build_cover(story):
    story.append(Spacer(1, 9*mm))
    story.append(CoverBanner(CONTENT_W, 82*mm))
    story.append(Spacer(1, 7*mm))
    meta_tbl = Table(
        [[P("<b>来源</b>", "h4"), P(META.get("source", ""), "body"),
          P("<b>作者</b>", "h4"), P(META.get("author", ""), "body")],
         [P("<b>字体</b>", "h4"), P("思源黑体 SC (Noto Sans SC) 400 / 700", "body"),
          P("<b>版式</b>", "h4"), P("A4 横向 · 七模块整册 · 模块②双栏（左原文 · 右批注）", "body")]],
        colWidths=[16*mm, 98*mm, 18*mm, CONTENT_W-16*mm-98*mm-18*mm])
    meta_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), CARD),
        ("BOX",(0,0),(-1,-1), 0.5, LINE), ("INNERGRID",(0,0),(-1,-1), 0.3, LINE),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ("LEFTPADDING",(0,0),(-1,-1), 10), ("RIGHTPADDING",(0,0),(-1,-1), 10),
        ("TOPPADDING",(0,0),(-1,-1), 7), ("BOTTOMPADDING",(0,0),(-1,-1), 7),
    ]))
    story.append(meta_tbl)
    story.append(Spacer(1, 6*mm))
    story.append(StarRule(CONTENT_W))
    story.append(Spacer(1, 5*mm))
    lead = Table([[P(
        "本篇精读与 HTML 版<b>七大模块一一对应</b>：① 选文定位 · ② 逐段精读 · ③ 逻辑脉络 · ④ 金句速览 · ⑤ 时政背景 · ⑥ 申论素材 · ⑦ 复盘行动。"
        "其中模块②采用<b>双栏对照</b>版式：<font color='#c7000b'><b>左栏为原文</b></font>（米黄底 · 红边框），"
        "<font color='#2c4a6b'><b>右栏为批注</b></font>（米白底 · 细边框）。全文统一采用<b>思源黑体（Source Han Sans SC）</b>字族：正文 400、标题与强调 700。"
        + META.get("copyright", ""), "body")]], colWidths=[CONTENT_W-16*mm])
    lead.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), QUOTE_BG),
        ("LINEBEFORE",(0,0),(0,-1), 3, GOLD),
        ("LEFTPADDING",(0,0),(-1,-1), 14), ("RIGHTPADDING",(0,0),(-1,-1), 14),
        ("TOPPADDING",(0,0),(-1,-1), 10), ("BOTTOMPADDING",(0,0),(-1,-1), 10),
    ]))
    story.append(lead)
    story.append(PageBreak())

def build_m1(story):
    story.append(card_head(1, "选文定位 · 为什么读这篇", OCHRE))
    story.append(Spacer(1, 4*mm))
    for title, body in M1_BLOCKS:
        story.append(block(title, [P(body, "body")], OCHRE))
        story.append(Spacer(1, 3*mm))
    story.append(block("▎ 话题归类", [Chip(M1_CHIPS, CHIP_BG, RED2, CHIP_BD, fs=8.6, h=16, pad=8)], OCHRE))
    story.append(Spacer(1, 3*mm))
    fit_tbl = Table([[
        [P(M1_FIT[0][0], "body"), Spacer(1, 2), P(M1_FIT[0][1], "body")],
        [P(M1_FIT[1][0], "body"), Spacer(1, 2), P(M1_FIT[1][1], "body")],
    ], [
        [P(M1_FIT[2][0], "body"), Spacer(1, 2), P(M1_FIT[2][1], "body")],
        [P(M1_FIT[3][0], "body"), Spacer(1, 2), P(M1_FIT[3][1], "body")],
    ]], colWidths=[(CONTENT_W-8*mm)/2, (CONTENT_W-8*mm)/2])
    fit_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), colors.white),
        ("BOX",(0,0),(-1,-1), 0.4, colors.HexColor("#e0cfae")),
        ("INNERGRID",(0,0),(-1,-1), 0.4, colors.HexColor("#e8dcc0")),
        ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
        ("TOPPADDING",(0,0),(-1,-1), 8), ("BOTTOMPADDING",(0,0),(-1,-1), 8),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    story.append(block("▎ 申论契合度评级：<font color='#c7000b'>高 ★★★★★</font>", [fit_tbl], OCHRE))
    story.append(Spacer(1, 3*mm))
    flows = []
    for i, s in enumerate(M1_STRATEGY):
        if i: flows.append(Spacer(1, 3))
        flows.append(P(s, "body"))
    story.append(block("▎ 精读策略建议", flows, OCHRE))
    story.append(PageBreak())

def build_m2(story):
    story.append(card_head(2, "逐段精读 · 左原文 · 右批注", RED))
    story.append(Spacer(1, 4*mm))
    for d in SEGMENTS:
        left_inner = [SegTag(d["segno"]), Spacer(1, 2.5), orig_box([P(d["orig"], "orig")])]
        right_inner = func_chip(d["func"], d["chips"])
        for i, n in enumerate(d["notes"]):
            if i: right_inner.append(Spacer(1, 4))
            right_inner.append(P(n, "note_body"))
        if d.get("sent"):
            right_inner.append(Spacer(1, 5))
            right_inner.append(sent_box(d["sent"]))
        seg_tbl = Table([[left_inner, note_box(right_inner)]], colWidths=[COL_L, COL_R+COL_GAP])
        seg_tbl.setStyle(TableStyle([
            ("VALIGN",(0,0),(-1,-1),"TOP"),
            ("LEFTPADDING",(0,0),(0,0), 0), ("RIGHTPADDING",(0,0),(0,0), COL_GAP),
            ("LEFTPADDING",(1,0),(1,0), 0), ("RIGHTPADDING",(1,0),(1,0), 0),
            ("TOPPADDING",(0,0),(-1,-1), 0), ("BOTTOMPADDING",(0,0),(-1,-1), 0),
        ]))
        story.append(KeepTogether(seg_tbl))
        story.append(Spacer(1, 4.5*mm))
    story.append(PageBreak())

def build_m3(story):
    story.append(card_head(3, "逻辑脉络 · 一眼看清骨架", NAVY))
    story.append(Spacer(1, 5*mm))
    root_w = 96*mm
    root = Table([[P(M3_ROOT, "mm_root")]], colWidths=[root_w])
    root.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), NAVY),
        ("LEFTPADDING",(0,0),(-1,-1), 10), ("RIGHTPADDING",(0,0),(-1,-1), 10),
        ("TOPPADDING",(0,0),(-1,-1), 8), ("BOTTOMPADDING",(0,0),(-1,-1), 8),
        ("ALIGN",(0,0),(-1,-1),"CENTER"),
    ]))
    ro = Table([["", root, ""]], colWidths=[(CONTENT_W-root_w)/2, root_w, (CONTENT_W-root_w)/2])
    ro.setStyle(TableStyle([("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
                            ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0)]))
    story.append(ro); story.append(Spacer(1, 6*mm))
    for title, subs in M3_ROWS:
        l1 = Table([[P(title, "mm_l1")]], colWidths=[CONTENT_W*0.31])
        l1.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#e7eef7")),
            ("BOX",(0,0),(-1,-1), 0.6, colors.HexColor("#bcd0e6")),
            ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
            ("TOPPADDING",(0,0),(-1,-1), 7), ("BOTTOMPADDING",(0,0),(-1,-1), 7),
            ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ]))
        l2f = []
        for s in subs:
            l2f.append(P("· " + s, "mm_l2")); l2f.append(Spacer(1, 2))
        l2 = Table([[l2f]], colWidths=[CONTENT_W*0.67])
        l2.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#f3f7fc")),
            ("LINEBEFORE",(0,0),(0,-1), 1.2, colors.HexColor("#9fb8d4")),
            ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
            ("TOPPADDING",(0,0),(-1,-1), 6), ("BOTTOMPADDING",(0,0),(-1,-1), 6),
            ("VALIGN",(0,0),(-1,-1),"TOP"),
        ]))
        row = Table([[l1, "", l2]], colWidths=[CONTENT_W*0.31, CONTENT_W*0.02, CONTENT_W*0.67])
        row.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
            ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
            ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0)]))
        story.append(row); story.append(Spacer(1, 3*mm))
    story.append(Spacer(1, 2*mm))
    tip = Table([[P(M3_TIP, "body")]], colWidths=[CONTENT_W-10*mm])
    tip.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), QUOTE_BG), ("LINEBEFORE",(0,0),(0,-1), 3, GOLD),
        ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
        ("TOPPADDING",(0,0),(-1,-1), 8), ("BOTTOMPADDING",(0,0),(-1,-1), 8),
    ]))
    story.append(tip)
    story.append(PageBreak())

def build_m4(story):
    story.append(card_head(4, "金句速览 · 可背清单（按功能分组）", GOLD))
    story.append(Spacer(1, 5*mm))
    for gname, quotes in M4_GROUPS:
        header = Table([[P(gname, "h4")]], colWidths=[CONTENT_W])
        header.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#f5ecd4")),
            ("LINEBEFORE",(0,0),(0,-1), 3, GOLD),
            ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
            ("TOPPADDING",(0,0),(-1,-1), 5), ("BOTTOMPADDING",(0,0),(-1,-1), 5),
        ]))
        story.append(header); story.append(Spacer(1, 2*mm))
        for src, txt, note in quotes:
            row = Table([[P(f"<b>{src}</b>", "white8"),
                          [P(f"<font color='#a5812f'>★</font> &nbsp;{txt}", "quote"), Spacer(1, 2), P(note, "quote_src")]]],
                        colWidths=[18*mm, CONTENT_W-18*mm])
            row.setStyle(TableStyle([
                ("BACKGROUND",(0,0),(0,0), GOLD), ("BACKGROUND",(1,0),(1,0), QUOTE_BG),
                ("VALIGN",(0,0),(-1,-1),"MIDDLE"), ("ALIGN",(0,0),(0,0),"CENTER"),
                ("LEFTPADDING",(0,0),(-1,-1), 10), ("RIGHTPADDING",(0,0),(-1,-1), 10),
                ("TOPPADDING",(0,0),(-1,-1), 7), ("BOTTOMPADDING",(0,0),(-1,-1), 7),
                ("LINEBELOW",(0,0),(-1,0), 0.4, colors.HexColor("#f0e6c8")),
            ]))
            story.append(row)
        story.append(Spacer(1, 4*mm))
    story.append(P(M4_NOTE, "sub"))
    story.append(PageBreak())

def build_m5(story):
    story.append(card_head(5, "时政背景 · 知其所然", TEAL))
    story.append(Spacer(1, 5*mm))
    def bg_cell(tag, title, body):
        inner = [Chip([tag], TEAL, colors.white, TEAL, fs=8, h=14, pad=6), Spacer(1, 3),
                 P(f"<b>{title}</b>", "mat_h"), Spacer(1, 3), P(body, "body_sm")]
        t = Table([[inner]], colWidths=[CONTENT_W*0.49-8*mm])
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), TEAL_BG), ("LINEBEFORE",(0,0),(0,-1), 2.5, TEAL),
            ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
            ("TOPPADDING",(0,0),(-1,-1), 9), ("BOTTOMPADDING",(0,0),(-1,-1), 9),
            ("VALIGN",(0,0),(-1,-1),"TOP"),
        ]))
        return t
    for i in range(0, len(M5_ITEMS), 2):
        left = bg_cell(*M5_ITEMS[i]); right = bg_cell(*M5_ITEMS[i+1]) if i+1 < len(M5_ITEMS) else ""
        row = Table([[left, "", right]], colWidths=[CONTENT_W*0.49, CONTENT_W*0.02, CONTENT_W*0.49])
        row.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
            ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
            ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0)]))
        story.append(row); story.append(Spacer(1, 3*mm))
    rh = Table([[P("▎ 延伸阅读（权威出处）", "h4")]], colWidths=[CONTENT_W])
    rh.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#e5f0ee")), ("LINEBEFORE",(0,0),(0,-1), 3, TEAL),
        ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
        ("TOPPADDING",(0,0),(-1,-1), 5), ("BOTTOMPADDING",(0,0),(-1,-1), 5),
    ]))
    story.append(rh); story.append(Spacer(1, 3*mm))
    rf = []
    for i, r in enumerate(M5_REFS, 1):
        rf.append(P(f"<b>{i}.</b> &nbsp;{r}", "body_sm")); rf.append(Spacer(1, 2))
    rt = Table([[rf]], colWidths=[CONTENT_W-4*mm])
    rt.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), CARD), ("BOX",(0,0),(-1,-1), 0.4, LINE),
        ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
        ("TOPPADDING",(0,0),(-1,-1), 8), ("BOTTOMPADDING",(0,0),(-1,-1), 8),
    ]))
    story.append(rt); story.append(Spacer(1, 3*mm))
    story.append(P(M5_NOTE, "sub"))
    story.append(PageBreak())

def build_m6(story):
    story.append(card_head(6, "申论素材 · 转化即用", PLUM))
    story.append(Spacer(1, 4*mm))
    story.append(mat_section_header("▎ 一、标题题式（可复用）"))
    story.append(Spacer(1, 3*mm))
    for tag, name, desc, orig, imit in M6_TITLES:
        inner = [Chip([tag], PLUM, colors.white, PLUM, fs=8, h=14, pad=6), Spacer(1, 3),
                 P(f"<b>{name}</b>", "mat_h"), Spacer(1, 2), P(desc, "mat_b"), Spacer(1, 5)]
        inner += dui_row(orig, imit, MAT_IN)
        story.append(mat_wrap(inner)); story.append(Spacer(1, 3*mm))
    story.append(Spacer(1, 1*mm))
    story.append(mat_section_header("▎ 二、句式模板（含原句 + 仿写）"))
    story.append(Spacer(1, 3*mm))
    for tag, name, tpl, orig, imit in M6_SENTS:
        inner = [Chip([tag], PLUM, colors.white, PLUM, fs=8, h=14, pad=6), Spacer(1, 3),
                 P(f"<b>{name}</b>", "mat_h"), Spacer(1, 4)]
        tt = Table([[P(f"<font color='#6d4c8f'><b>模板</b></font> &nbsp;{tpl}", "mat_b")]], colWidths=[MAT_IN])
        tt.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), colors.white), ("BOX",(0,0),(-1,-1), 0.5, PLUM),
            ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
            ("TOPPADDING",(0,0),(-1,-1), 7), ("BOTTOMPADDING",(0,0),(-1,-1), 7),
        ]))
        inner.append(tt); inner.append(Spacer(1, 5))
        inner += dui_row(orig, imit, MAT_IN)
        story.append(mat_wrap(inner)); story.append(Spacer(1, 3*mm))
    story.append(Spacer(1, 1*mm))
    story.append(mat_section_header("▎ 三、分论点示范（一组）"))
    story.append(Spacer(1, 3*mm))
    cw3 = (MAT_IN - 6*mm)/3
    fen = [Chip(["总论点"], PLUM, colors.white, PLUM, fs=8, h=14, pad=6), Spacer(1, 3),
           P(f"<b>{M6_FEN['total']}</b>", "mat_h"), Spacer(1, 3),
           P("迁移本文骨架，可拆为三个分论点：", "mat_b"), Spacer(1, 5)]
    cells = []
    for i, (nm, bd) in enumerate(M6_FEN["subs"], 1):
        cells.append([P(f"<b>{nm}</b>", "mat_h"), Spacer(1, 2), P(bd, "mat_b")])
    fen.append(Table([cells], colWidths=[cw3, cw3, cw3], style=TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), colors.white), ("BOX",(0,0),(-1,-1), 0.4, colors.HexColor("#d9c9ea")),
        ("INNERGRID",(0,0),(-1,-1), 0.4, colors.HexColor("#e4d8f1")),
        ("LEFTPADDING",(0,0),(-1,-1), 10), ("RIGHTPADDING",(0,0),(-1,-1), 10),
        ("TOPPADDING",(0,0),(-1,-1), 8), ("BOTTOMPADDING",(0,0),(-1,-1), 8),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ])))
    fen.append(Spacer(1, 6))
    fen.append(P("<b>示范段落</b>", "mat_h")); fen.append(Spacer(1, 3))
    demo = Table([[P(M6_FEN["demo"], "mat_b")]], colWidths=[MAT_IN])
    demo.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), colors.white), ("BOX",(0,0),(-1,-1), 0.5, PLUM),
        ("LINEBEFORE",(0,0),(0,-1), 3, PLUM),
        ("LEFTPADDING",(0,0),(-1,-1), 14), ("RIGHTPADDING",(0,0),(-1,-1), 14),
        ("TOPPADDING",(0,0),(-1,-1), 10), ("BOTTOMPADDING",(0,0),(-1,-1), 10),
    ]))
    fen.append(demo)
    story.append(mat_wrap(fen)); story.append(Spacer(1, 4*mm))
    story.append(mat_section_header("▎ 四、论据金句卡（考前集中背诵）"))
    story.append(Spacer(1, 3*mm))
    def kcard(title, viewpoint, quote_txt, scene, src):
        inner = [P(f"<b>{title}</b>", "mat_h"), Spacer(1, 3),
                 P(f"<font color='#6d4c8f'><b>观点</b></font> &nbsp;{viewpoint}", "mat_b"), Spacer(1, 3),
                 P(f"<font color='#a5812f'><b>★ 原句（{src}）</b></font> &nbsp;{quote_txt}", "mat_b"), Spacer(1, 3),
                 P(f"<font color='#1f6f6b'><b>替换场景</b></font> &nbsp;{scene}", "mat_b")]
        t = Table([[inner]], colWidths=[cw3])
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), colors.white), ("BOX",(0,0),(-1,-1), 0.5, colors.HexColor("#e4d8f1")),
            ("LINEBEFORE",(0,0),(0,-1), 2.5, PLUM),
            ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
            ("TOPPADDING",(0,0),(-1,-1), 9), ("BOTTOMPADDING",(0,0),(-1,-1), 9),
            ("VALIGN",(0,0),(-1,-1),"TOP"),
        ]))
        return t
    gapw = (CONTENT_W - 3*cw3)/2
    for i in range(0, len(M6_CARDS), 3):
        chunk = M6_CARDS[i:i+3]
        cells = []
        for c in chunk:
            cells.append(kcard(*c))
        while len(cells) < 3:
            cells.append("")
        row = Table([[cells[0], "", cells[1], "", cells[2]]], colWidths=[cw3, gapw, cw3, gapw, cw3])
        row.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
            ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
            ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0)]))
        story.append(row); story.append(Spacer(1, 3*mm))
    story.append(Spacer(1, 1*mm))
    story.append(mat_section_header("▎ 五、仿写练习与批改要点"))
    story.append(Spacer(1, 3*mm))
    for tag, title, ref_txt, points in M6_EXS:
        inner = [Chip([tag], PLUM, colors.white, PLUM, fs=8, h=14, pad=6), Spacer(1, 3),
                 P(f"<b>{title}</b>", "mat_h"), Spacer(1, 4),
                 P("<font color='#8a4b12'><b>参考写法</b></font>", "mat_b"), Spacer(1, 2)]
        ref = Table([[P(ref_txt, "mat_b")]], colWidths=[MAT_IN])
        ref.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#fbf3e6")), ("LINEBEFORE",(0,0),(0,-1), 3, OCHRE),
            ("LEFTPADDING",(0,0),(-1,-1), 12), ("RIGHTPADDING",(0,0),(-1,-1), 12),
            ("TOPPADDING",(0,0),(-1,-1), 8), ("BOTTOMPADDING",(0,0),(-1,-1), 8),
        ]))
        inner.append(ref); inner.append(Spacer(1, 5))
        inner.append(P(f"<font color='#c7000b'><b>批改要点</b></font> &nbsp;{points}", "mat_b"))
        story.append(mat_wrap(inner)); story.append(Spacer(1, 3*mm))
    loss_inner = [Chip(["常见失分点"], RED2, colors.white, RED2, fs=8, h=14, pad=6), Spacer(1, 4)]
    for i, l in enumerate(M6_LOSS):
        if i: loss_inner.append(Spacer(1, 2))
        loss_inner.append(P(l, "mat_b"))
    loss = Table([[loss_inner]], colWidths=[CONTENT_W-4*mm])
    loss.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#fff5f5")), ("BOX",(0,0),(-1,-1), 0.5, colors.HexColor("#e8b4b4")),
        ("LEFTPADDING",(0,0),(-1,-1), 14), ("RIGHTPADDING",(0,0),(-1,-1), 14),
        ("TOPPADDING",(0,0),(-1,-1), 10), ("BOTTOMPADDING",(0,0),(-1,-1), 10),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    story.append(loss)
    story.append(PageBreak())

def build_m7(story):
    story.append(card_head(7, "复盘行动 · 复习与自测", GRAY))
    story.append(Spacer(1, 5*mm))
    af = [P("▎ 三档任务清单", "mat_h"), Spacer(1, 4)]
    for t, d in M7_ACT:
        af.append(P(f"<font color='#4b5563'><b>★ {t}</b></font> &nbsp;{d}", "mat_b")); af.append(Spacer(1, 5))
    act_box = Table([[af]], colWidths=[CONTENT_W*0.5-4*mm])
    act_box.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), CARD), ("BOX",(0,0),(-1,-1), 0.5, LINE),
        ("LINEBEFORE",(0,0),(0,-1), 3, GRAY),
        ("LEFTPADDING",(0,0),(-1,-1), 14), ("RIGHTPADDING",(0,0),(-1,-1), 14),
        ("TOPPADDING",(0,0),(-1,-1), 10), ("BOTTOMPADDING",(0,0),(-1,-1), 10),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    qf = [P("▎ 自测题（合上材料作答）", "mat_h"), Spacer(1, 4)]
    for i, q in enumerate(M7_QUIZ, 1):
        qf.append(P(f"<font color='#2c4a6b'><b>{i}.</b></font> &nbsp;{q}", "mat_b")); qf.append(Spacer(1, 5))
    quiz_box = Table([[qf]], colWidths=[CONTENT_W*0.5-4*mm])
    quiz_box.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), CARD), ("BOX",(0,0),(-1,-1), 0.5, LINE),
        ("LINEBEFORE",(0,0),(0,-1), 3, NAVY),
        ("LEFTPADDING",(0,0),(-1,-1), 14), ("RIGHTPADDING",(0,0),(-1,-1), 14),
        ("TOPPADDING",(0,0),(-1,-1), 10), ("BOTTOMPADDING",(0,0),(-1,-1), 10),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    act_tbl = Table([[act_box, "", quiz_box]], colWidths=[CONTENT_W*0.5-2*mm, 4*mm, CONTENT_W*0.5-2*mm])
    act_tbl.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0)]))
    story.append(act_tbl)
    story.append(Spacer(1, 8*mm))
    story.append(StarRule(CONTENT_W))
    story.append(Spacer(1, 4*mm))
    final = Table([[
        P("<b>由「人民日报精读 · 双交付套件」生成</b> · " + META.get("copyright", ""), "body"),
        Spacer(1, 3),
        P("原文出处：" + META.get("source", "") + " · " + META.get("title", ""), "body_sm"),
    ]], colWidths=[CONTENT_W])
    final.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), QUOTE_BG), ("BOX",(0,0),(-1,-1), 0.5, GOLD),
        ("LEFTPADDING",(0,0),(-1,-1), 16), ("RIGHTPADDING",(0,0),(-1,-1), 16),
        ("TOPPADDING",(0,0),(-1,-1), 12), ("BOTTOMPADDING",(0,0),(-1,-1), 12),
        ("ALIGN",(0,0),(-1,-1),"CENTER"),
    ]))
    story.append(final)

# ============================================================================
# 【主构建】
# ============================================================================
def build():
    doc = BaseDocTemplate(
        META.get("output", "close-reading.pdf"),
        pagesize=landscape(A4),
        leftMargin=MARGIN_L, rightMargin=MARGIN_R,
        topMargin=MARGIN_T, bottomMargin=MARGIN_B,
        title=META.get("title", "close-reading"),
        author=META.get("author", ""),
        subject=f"{META.get('brand', '')} · 七模块整册双栏精读 PDF",
    )
    fc = Frame(MARGIN_L, MARGIN_B, CONTENT_W, PH-MARGIN_T-MARGIN_B,
               leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0, id="cover")
    fb = Frame(MARGIN_L, MARGIN_B, CONTENT_W, PH-MARGIN_T-MARGIN_B,
               leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0, id="body")
    doc.addPageTemplates([
        PageTemplate(id="cover", frames=[fc], onPage=on_cover),
        PageTemplate(id="body",  frames=[fb], onPage=on_page),
    ])
    story = []
    build_cover(story)
    for i, f in enumerate(story):
        if isinstance(f, PageBreak):
            story.insert(i, NextPageTemplate("body")); break
    build_m1(story); build_m2(story); build_m3(story); build_m4(story)
    build_m5(story); build_m6(story); build_m7(story)
    print(f"[BUILD] segments={len(SEGMENTS)} | quotes={sum(len(q) for _, q in M4_GROUPS)} | output={META.get('output')}")
    doc.build(story)
    print("[OK ] PDF built:", META.get("output"))
    print("      next: reference.md §6 三重自检 + §7 模块对应验收")

if __name__ == "__main__":
    build()
