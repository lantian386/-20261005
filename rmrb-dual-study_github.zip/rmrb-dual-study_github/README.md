# 人民日报精读天团 · 双交付套件（rmrb-dual-study）

> **CodeBuddy 插件 · 五角色协作团队**
> 一次精读、双份交付：**报章风 HTML 精读文章**（7 模块卡）+ **A4 横向「左原文 · 右批注」七模块打印卷 PDF**。
> 两版产物七大模块逐一对应，PDF 须先经用户确认后构建。

- 版本 / Version：`1.0.2`
- 作者 / Author：蓝天 (Lantian)
- 许可证 / License：[MIT](./LICENSE)

---

## 目录 / Table of Contents

- [简介 / Overview](#简介-overview)
- [功能特性 / Features](#功能特性-features)
- [团队阵容 / The Team](#团队阵容-the-team)
- [目录结构 / Repository Layout](#目录结构-repository-layout)
- [安装 / Install](#安装-install)
- [使用 / Usage](#使用-usage)
- [双交付铁律 / Hard Rules](#双交付铁律-hard-rules)
- [资源与脚本 / Assets & Scripts](#资源与脚本-assets--scripts)
- [字体供给 / Fonts](#字体供给-fonts)
- [依赖 / Dependencies](#依赖-dependencies)
- [版权与声明 / Copyright & Disclaimer](#版权与声明-copyright--disclaimer)
- [English](#english)

---

## 简介 / Overview

本仓库是一个 **CodeBuddy 插件包**（清单见 `.codebuddy-plugin/plugin.json`）。它把「人民日报精读天团」五角色协作 SOP 与「双栏精读 PDF 流水线」整合为一个可发布、可复用的专家包。

核心理念是 **一次精读、双份交付**：

1. **HTML 精读文章**（默认交付，屏幕交互，自包含可离线打开）——报章风「纸墨红金」七模块卡。
2. **A4 横向打印卷 PDF**（经用户确认后追加，纸面打印）——左栏原文、右栏批注，七模块整册，思源黑体 SC。

七模块在 HTML 与 PDF 中**逐一对应**：① 选文定位 ② 逐段精读双栏 ③ 逻辑脉络 ④ 金句速览 ⑤ 时政背景 ⑥ 申论素材 ⑦ 复盘行动。

---

## 功能特性 / Features

- **五角色团队编排**：主理人统筹，荐读官 / 文本精读师 / 时政背景拓展官 / 申论写作转化教练各司其职。
- **六阶段 SOP**：选文 → 精读拆解 → 背景拓展 → 素材转化 → HTML 汇编 → PDF 打印卷。
- **确认制交付**：HTML 默认产出；PDF 打印卷先征求用户同意（整册 or 仅双栏段）再构建。
- **数据驱动 PDF 模板**：`build_full_pdf_template.py` 内置 8 个内容注入区，填数即出整册，版式参数以 `reference.md` 为唯一依据。
- **三重自检 + 模块对应验收**：页数 / 尺寸、越界告警、文本还原 + 7 模块标题与数量一致。

---

## 团队阵容 / The Team

| 角色 | 花名 | 职责 |
|---|---|---|
| 主理人（统筹） | 沈观澜 | 统筹「选文 → 精读 → 背景 → 素材 → HTML → PDF」全流程，审校汇编；主持 HTML 汇编与 PDF 确认门 |
| 荐读官 | 陆声闻 | 荐读选文、体裁定位、申论契合度评级与精读策略（Phase 1） |
| 文本精读师 | 程析文 | 逐段拆解段意与结构手法、赏析好词好句、逻辑脉络图与可背金句（Phase 2 / 脉络） |
| 时政背景拓展官 | 谭青史 | 时政背景、政策脉络、事实核注与延伸阅读（注明权威出处）（Phase 3） |
| 申论写作转化教练 | 吴立言 | 标题题式、句式模板、分论点示范、论据金句卡与仿写练习（Phase 4） |

各角色定义见 `agents/` 目录；头像见 `avatars/` 目录。

---

## 目录结构 / Repository Layout

```
rmrb-dual-study/
├── .codebuddy-plugin/
│   └── plugin.json            # 插件清单（CodeBuddy 插件入口）
├── README.md                  # 本文件
├── LICENSE                    # MIT
├── .gitignore
├── settings.json              # 默认 Agent 配置
├── agents/                    # 五角色定义（team-lead + 4 成员）
│   ├── rmrb-dual-study-team-lead.md
│   ├── lu-shengwen.md
│   ├── cheng-xiwen.md
│   ├── tan-qingshi.md
│   └── wu-liyan.md
├── avatars/                   # 团队 + 角色头像（PNG，512×512）
│   ├── rmrb-dual-study-team.png
│   ├── rmrb-dual-study-team-lead.png
│   ├── lu-shengwen.png
│   ├── cheng-xiwen.png
│   ├── tan-qingshi.png
│   └── wu-liyan.png
└── skills/
    └── rmrb-dual-study/
        ├── SKILL.md           # 主技能：六阶段 SOP + 双交付铁律 + 版式规范
        ├── reference.md       # 版式参数细则 / 避坑 Top10 / 自检与验收（§0–§7）
        └── assets/
            ├── html_template.html          # HTML 七模块模板（纸墨红金·报章风）
            ├── build_full_pdf_template.py  # PDF 七模块整册构建模板（数据驱动 8 注入区）
            └── fetch_fonts.sh              # 思源黑体 SC TTF 一键供给
```

---

## 安装 / Install

### 方式 A：作为 CodeBuddy 插件导入

1. 克隆本仓库到本地：
   ```bash
   git clone <your-fork-or-this-repo-url> rmrb-dual-study
   ```
2. 将 `rmrb-dual-study/` 目录放入你的 CodeBuddy 插件目录（或通过 CodeBuddy 的「导入插件 / 插件市场本地目录」功能加载）。
3. 插件清单 `.codebuddy-plugin/plugin.json` 会被自动识别；团队主理人 `rmrb-dual-study-team-lead` 与内嵌技能 `rmrb-dual-study` 随之可用。

### 方式 B：仅取用内嵌技能

若你只需 PDF / HTML 双交付流水线，可单独复制 `skills/rmrb-dual-study/` 到任意支持 Agent Skills 的主机（目录结构保持不变即可）。技能本身已内置「六阶段单 Agent 顺序执行」SOP，不依赖团队编排层也能独立运行。

> 说明：原包 README 中提到的 `scripts/register_expert.py` / `scripts/package_expert.py` 属 WorkBuddy 专家包体系，本仓库为 CodeBuddy 插件形态，不再包含这两个脚本。

---

## 使用 / Usage

插件加载后，向主理人发起请求即可。常用入口（quick prompts）：

- 「精读这篇人民日报文章：<贴入链接或原文>」→ 默认走 Workflow A：先交付 HTML，随后询问是否生成打印卷。
- 「把这篇评论做成精读：逐段拆解 + 金句 + 申论素材」→ 综合精读。
- 「生成 A4 双栏打印卷（七模块整册）」→ 确认后走 PDF 流水线。
- 「只要 HTML」→ 单交付模式，不产 PDF（版式规范不变）。

### 预设 Workflow

| Workflow | 触发 | 编排 |
|---|---|---|
| A（默认·双交付） | 给原文 + 综合精读请求 | P1 → P2∥P3（并行）→ P4 → P5(HTML) → 确认门 → P6(PDF) |
| B（轻量速读） | 只看大意 / 拆骨架 | P1 → 仅模块①③（轻量）+ 可选单卡 HTML |
| C（素材单卡） | 已有笔记只要素材/金句/仿写 | 仅模块⑥ → 单卡 HTML |
| 单交付 | 明确只要 HTML / 只要打印卷 | 版式规范不变 |

---

## 双交付铁律 / Hard Rules

1. **确认制交付**：HTML 为默认交付物；PDF 打印卷在 HTML 交付后**向用户确认**（是否生成 / 整册 or 仅双栏段），获准后才构建；未经确认不执行 PDF 生成。
2. **模块对应**：PDF ≡ HTML 七模块；**禁止 PDF 只出双栏段而缺其余模块**。
3. **双栏版式**：左栏原文（米黄底 + 主色左边框 + 段题红标签在框外上方 + 重点红粗内联 + ★金句金色），右栏批注（功能条 → 胶囊 chips → 赏析 → 藏蓝句式亮点块）。
4. **排版铁律**：全篇 `TA_LEFT`（禁 `TA_JUSTIFY` 短行拉伸）；chips 自动换行（禁单行硬塞溢出）；思源黑体 SC 400 正文 / 700 标题与 `<b>`（须 `registerFontFamily` 走真粗体）；页眉红金双线 + 品牌 + 出处 + 页码；页脚版权 + 页码。
5. **忠于原文**：引用逐字准确；时政注明出处年份；素材标段号。
6. **版权与定位**：两版页脚均标「个人学习精读 · 原文版权归《人民日报》及作者所有」+ 原文链接；不声明对原文享有版权。
7. **执行标准唯一**：PDF 构建严格按本套件——模板唯一（`build_full_pdf_template.py`）、参数唯一（`reference.md` §2）、自检必过（§6 三重 + §7 模块对应）；确认门未过不构建，自检未绿不交付。

---

## 资源与脚本 / Assets & Scripts

- `skills/rmrb-dual-study/assets/html_template.html` — HTML 七模块模板（内联 CSS、可离线）。
- `skills/rmrb-dual-study/assets/build_full_pdf_template.py` — PDF 七模块整册构建模板（数据驱动 8 注入区：META / SEGMENTS / M1 / M3 / M4 / M5 / M6 / M7）。填数后 `python3 build_full_pdf_template.py` 即出整册；模板自带最小示例数据，可先空跑验证环境。
- `skills/rmrb-dual-study/assets/fetch_fonts.sh` — 思源黑体 SC TTF 一键供给（jsDelivr 多节点回退 + fontTools 实例化）。
- `skills/rmrb-dual-study/reference.md` — 版式参数细则 / 避坑 Top10 / 自检脚本 / 验收清单（§0–§7）。

PDF 自检要点（详见 `reference.md` §6 / §7）：

```bash
# A 页数 + 尺寸
python3 -c "from pypdf import PdfReader; r=PdfReader('OUTPUT.pdf'); \
print(len(r.pages), float(r.pages[0].mediabox.width), float(r.pages[0].mediabox.height))"
# B 越界告警
grep -iE 'warning|overflow|too large|frame' build.log && echo 有告警 || echo 无越界告警
# C 文本还原抽查（首/中/尾）
python3 -c "from pypdf import PdfReader; import re; r=PdfReader('OUTPUT.pdf'); n=len(r.pages)
for i in [0,n//2,n-1]: t=re.sub(r'\s+',' ',r.pages[i].extract_text()); print(t[:240])"
```

---

## 字体供给 / Fonts

PDF 需要思源黑体 SC 真 TrueType 静态实例（`NotoSansSC-400.ttf` + `NotoSansSC-700.ttf`）。

```bash
bash skills/rmrb-dual-study/assets/fetch_fonts.sh "$WORKDIR/.fonts"
```

- 缓存命中（`.fonts/` 下两文件均 > 5MB）自动跳过。
- 严禁 `/system/fonts/NotoSansCJK*.ttc`（CFF 轮廓，reportlab 拒嵌）。
- 严禁 `raw.githubusercontent.com`（部分网络下连接被重置）；思源宋体在 jsDelivr 持续 403，故全文黑体。
- 全线失败时降级：系统 `HarmonyOS_Sans_SC.ttf` 或 `FZHeiT-SC-{Regular,Bold}.ttf`。

---

## 依赖 / Dependencies

- Python 3.8+
- `reportlab`（PDF 构建）
- `fontTools`（字体实例化）
- `pypdf`（自检文本抽取，可选）
- `curl`（字体下载）

---

## 版权与声明 / Copyright & Disclaimer

- 本插件为**个人学习精读**用途的工具；精读产物中的原文版权归《人民日报》及原作者所有，本工具不主张对原文享有任何版权。
- 两版产物页脚均须包含版权声明与原文链接。
- 代码与文档以 MIT 许可证发布（见 [LICENSE](./LICENSE)）。

---

## English

### People's Daily Close-Reading Squad · Dual-Delivery Kit (`rmrb-dual-study`)

A **CodeBuddy plugin package** (manifest: `.codebuddy-plugin/plugin.json`) that consolidates a five-person "close-reading squad" SOP and a two-column PDF pipeline into one publishable, reusable expert pack.

**One pass, two deliverables:**

1. **Newspaper-style HTML close-reading article** (default, screen-interactive, self-contained & offline) — seven module cards in an "ink & red-gold" broadsheet look.
2. **A4 landscape print-volume PDF** (added after user confirmation, for print) — left column = original text, right column = annotation, seven modules, Source Han Sans SC.

The seven modules map 1:1 between HTML and PDF: ① Selection & positioning ② Paragraph-by-paragraph two-column ③ Logic map ④ Quote gallery ⑤ Current-affairs background ⑥ Essay-exam materials ⑦ Review & self-test.

**Install**

- As a CodeBuddy plugin: clone this repo, then load the `rmrb-dual-study/` directory via CodeBuddy's plugin import / local-plugin UI. The manifest is auto-detected.
- Skill-only: copy `skills/rmrb-dual-study/` into any Agent-Skills host. The skill already embeds a single-agent six-phase SOP, so it runs without the team layer.

**Hard rules**

- Confirmation gate: HTML is the default deliverable; the PDF print volume is built only after the user confirms (full booklet vs. two-column only).
- Module parity: PDF ≡ HTML seven modules; never ship PDF with only the two-column section.
- Layout: `TA_LEFT` throughout (no `TA_JUSTIFY` stretching); chips auto-wrap; Source Han Sans SC 400 body / 700 headings & `<b>` (use `registerFontFamily` for true bold); red-gold header rule + footer copyright + page numbers.
- Fidelity: quote verbatim; cite sources with year for current affairs; tag materials with paragraph numbers.
- Copyright: both deliverables must footer "personal study close-reading · original © People's Daily & its authors" + source link; the tool claims no copyright over the source text.

**Assets & scripts**

- `assets/html_template.html` — HTML seven-module template.
- `assets/build_full_pdf_template.py` — data-driven PDF builder with 8 injection zones (META / SEGMENTS / M1 / M3 / M4 / M5 / M6 / M7).
- `assets/fetch_fonts.sh` — one-shot Source Han Sans SC TTF fetcher (jsDelivr multi-mirror + fontTools instancing).
- `reference.md` — layout parameters, top-10 pitfalls, self-check & acceptance checklist (§0–§7).

**Dependencies**: Python 3.8+, `reportlab`, `fontTools`, `pypdf` (optional, for self-check), `curl`.

**License**: MIT — see [LICENSE](./LICENSE).
